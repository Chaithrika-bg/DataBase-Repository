import _ from 'lodash'
import fetch from 'node-fetch'
const DB_URL = 'http://localhost:5000/'

export const postRequestOptions = (body, method) => {
  return {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
    body:
      body &&
      JSON.stringify({
        ...body,
      }),
  }
}

export const fetchPostDB = (db, body) => {
  return new Promise((res, rej) => {
    fetch(`${DB_URL}${db}`, postRequestOptions(body, 'POST'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}

export const fetchPostByIdDB = (db, id, body) => {
  return new Promise((res, rej) => {
    let _body = { id, value: body }
    fetch(`${DB_URL}${db}`, postRequestOptions(_body, 'POST'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}

export const fetchPatchByIdDB = (db, id, body) => {
  return new Promise((res, rej) => {
    fetch(`${DB_URL}${db + '/' + id}`, postRequestOptions(body, 'PATCH'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}
export const fetchPatchDB = (db, body) => {
  return new Promise((res, rej) => {
    fetch(`${DB_URL}${db}`, postRequestOptions(body, 'PATCH'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}

export const fetchDeleteDB = (db, id) => {
  return new Promise((res, rej) => {
    fetch(`${DB_URL}${db + '/' + id}`, postRequestOptions(undefined, 'DELETE'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}

export const fetchGetByIdDB = (db, id) => {
  return new Promise((res, rej) => {
    fetch(`${DB_URL}${db + '/' + id}`, postRequestOptions(undefined, 'GET'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}
export const fetchGetDB = async (db) => {
  return new Promise((res, rej) => {
    fetch(`${DB_URL}${db}`, postRequestOptions(undefined, 'GET'))
      .then((response) => response.json())
      .then((data) => {
        res(data)
      })
      .catch((error) => {
        console.log(error)
      })
  })
}
