'use strict'

import express from 'express'
import path from 'path'
import cors from 'cors'

import { dirname } from 'path'
import { fileURLToPath } from 'url'
import {
  fetchGetByIdDB,
  fetchGetDB,
  fetchPostByIdDB,
  fetchPostDB,
} from './db-service.js'

const app = express()
const { PORT } = process.env
const port = PORT || 5000
const __dirname = dirname(fileURLToPath(import.meta.url))
app.use(cors())
app.use(express.static(path.join(__dirname, '../')))
app.use(express.static(__dirname))
app.use(express.static(path.join(__dirname, '../', 'build')))
app.use(express.json({ limit: '2mb' }))

app.get('/api/users', async function (req, res) {
  const data = await fetchGetDB('users')
  res.json({ message: 'success', data })
})
app.get('/api/adopt', async function (req, res) {
  const data = await fetchGetDB('adopt')
  console.log(data)
  res.json({ message: 'success', data })
})
app.get('/api/donate', async function (req, res) {
  console.log(res.body)
  const data = await fetchGetDB('donate')
  res.json({ message: 'success', data })
})
app.get('/api/volunteer', async function (req, res) {
  const data = await fetchGetDB('volunteer')
  res.json({ message: 'success', data })
})
app.get('/api/scholorship', async function (req, res) {
  const data = await fetchGetDB('scholorship')
  res.json({ message: 'success', data })
})
app.get('/api/contact', async function (req, res) {
  const data = await fetchGetDB('contact')
  res.json({ message: 'success', data })
})

app.post('/api/users', async function (req, res) {
  await fetchPostDB('users', { id: req.body.userName, ...req.body })
  res.json({ message: 'success' })
})
app.post('/api/adopt', async function (req, res) {
  console.log(req.body)
  await fetchPostDB('adopt', req.body)
  res.json({ message: 'success' })
})
app.post('/api/donate', async function (req, res) {
  console.log(req.body)
  await fetchPostDB('donate', req.body)
  res.json({ message: 'success' })
})
app.post('/api/volunteer', async function (req, res) {
  console.log(req.body)
  await fetchPostDB('volunteer', req.body)
  res.json({ message: 'success' })
})
app.post('/api/scholorship', async function (req, res) {
  await fetchPostDB('scholorship', req.body)
  res.json({ message: 'success' })
})
app.post('/api/contact', async function (req, res) {
  await fetchPostDB('contact', req.body)
  res.json({ message: 'success' })
})

app.get('/api/login', async function (req, res) {
  const { Email, password } = req.body
  const user = await fetchGetByIdDB('users', Email)
  console.log(user, 'll')
  if (!user.Email) res.json({ message: 'user not exist' })
  else if (user?.password !== password)
    res.json({ message: 'Incorrect Password' })
  else res.json({ message: 'success', data: user })
})

app.get('/*', function (req, res) {
  res.send(`<h1 style="margin-left:45%">Bad Request...</h1>`)
})

app.listen(port)
